# Door Windows Center — sitio

Sitio estático de una página.

## Archivos

- `index.html` — la página
- `assets/` — fotos, logo y video
- `ds/` — estilos
- `support.js` — runtime de la página

## Publicar en Railway

1. Sube esta carpeta a un repositorio de GitHub.
2. En railway.app: New Project → Deploy from GitHub repo → elige el repositorio.
3. Railway detecta Node, instala `serve` y arranca con `npm start`.
4. Settings → Networking → Generate Domain para probarlo.
5. Custom Domain → `www.doorwindowscenter.com`. Railway da un valor CNAME que se copia en el DNS de GoDaddy.

## Publicar en cualquier hosting normal (cPanel, FTP)

Copiar el contenido de esta carpeta a `public_html`. `package.json` no hace falta ahí.
